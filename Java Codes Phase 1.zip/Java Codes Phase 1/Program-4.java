//4.Write a program to demonstrate the do while loop

public class DoWhileLoop {
    public static void main(String[] args) {
        System.out.println("Print numbers from 1 to 5");
        int i = 1; 
        do {
            System.out.println(i);
            i++; 
        } while (i <= 5); 
        System.out.println();
        
    }
}
