// 5.Write a program to demonstrate the for loop
 
public class ForLoopExample {
    public static void main(String[] args) {
        System.out.println("Print numbers from 1 to 5");
        for (int i = 1; i <= 5; i++) {
            System.out.println(i);
        }
        System.out.println();
  }
}